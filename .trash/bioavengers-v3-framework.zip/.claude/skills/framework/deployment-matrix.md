---
name: deployment-matrix
description: >
  Decision rules for when Claude Marchetti should use subagents vs agent teams. Reference
  before every agent spawning decision.
---

# Deployment Matrix — Crucible Systems

## Decision Rule

**Can the agents work independently, reporting results back?** → Subagent.
**Do the agents need to communicate with each other during the work?** → Agent Team.

## Subagent Characteristics

Single worker within the current session. Reports back to Claude Marchetti only. Cannot
message other agents. Own context window. Cost-effective. Best for focused, single-domain
tasks where the answer flows one direction.

## Agent Team Characteristics

Multiple independent Claude Code sessions. Peer-to-peer messaging via inbox files. Shared
task list with dependency tracking. Claude Marchetti acts as team lead. Each teammate loads
CLAUDE.md and skills independently. 3-4x token cost. Best for work requiring cross-domain
communication, negotiation, or adversarial exchange.

## The Table

| Task | Mechanism | Agents | Rationale |
|------|-----------|--------|-----------|
| Codebase reconnaissance | Subagent | Explore agent | Read-only research |
| Planning interview (multi-domain) | Agent Team | Marcus + James + Alexandra | Domain experts contribute questions |
| Planning interview (single-domain) | Single session | Claude Marchetti | PM interviews alone |
| Scaffold (single layer) | Subagent | One builder | Focused, no cross-talk needed |
| Scaffold (cross-layer) | Agent Team | Elena + Jennifer + Brian | Contract negotiation |
| Scaffold review | Subagent | Marcus alone | Architecture-only check |
| Core build (single layer) | Subagent | One builder | Focused implementation |
| Core build (cross-layer) | Agent Team | Elena + Jennifer | API contract negotiation |
| Core review (multi-reviewer) | Agent Team | Per scoping matrix | Cross-domain challenge |
| Core review (single reviewer) | Subagent | One reviewer | Focused verdict |
| Integration build | Agent Team | All builders | Cross-layer wiring |
| Integration review | Agent Team | Dmitri + Robert | Security + QA interplay |
| Polish build | Subagent | Jennifer | UI refinements |
| Polish review | Subagent or Team | Alexandra (+ Robert) | a11y + verification |
| Henrik gate | **ALWAYS Subagent** | Henrik alone | Independence is the point |
| Bug fix | Subagent chain | Builder → Robert → Henrik | Sequential, no cross-talk |
| Architecture decision | Agent Team | Marcus + James + Dmitri + Alexandra | Debate and converge |
| Documentation only | Subagent | One builder | Single-domain |

## Anti-Shortcutting

Claude Marchetti must not downgrade an Agent Team to subagents to save tokens. If the task
requires cross-domain communication, the token cost is justified. Skipping it means
cross-domain issues won't be caught until Henrik — or worse, production.
