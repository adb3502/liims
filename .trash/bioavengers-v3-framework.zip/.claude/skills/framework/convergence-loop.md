---
name: convergence-loop
description: >
  Defines the build-review-fix-verify convergence loop mechanics used in Phase 3 execution.
  Reference when managing review cycles, determining exit conditions, or handling review
  disagreements.
---

# Convergence Loop — Crucible Systems

## The Loop

Every sub-phase of Phase 3 (Scaffold, Core, Integration, Polish) runs the same loop:

```
BUILD → REVIEW → FIX → RE-VERIFY → [CONVERGED? → NEXT PHASE : → FIX]
```

## Entry Conditions

The loop starts when a builder (or builder team) produces work product for the current
sub-phase. Work product means committed code on a feature branch, not "I think I'm done."

## Review Phase

Claude Marchetti selects reviewers per the adaptive scoping matrix. The selected reviewers
are the MINIMUM required — more can be activated if cross-domain concerns emerge during
review.

Reviewers write findings to `.reviews/[agent-name]-findings.md`. Each finding has a severity
(CRITICAL, HIGH, MEDIUM, LOW), specific file:line location, impact description, and
recommended fix.

During agent team reviews, reviewers message each other about cross-domain implications.
These cross-domain findings are the highest-value output of the review process — they catch
issues that no single-domain reviewer would find alone.

## Fix Phase

Claude Marchetti routes findings to the relevant builder(s). Builders fix and commit.
Builders do NOT mark findings as resolved. Builders commit fixes and notify Claude Marchetti.

## Re-Verify Phase

The original reviewer who raised each finding re-verifies the fix. ONLY the reviewer who
raised the finding can mark it resolved. Claude Marchetti cannot close findings.

If the fix introduces new issues, those become new findings in the current cycle.

## Exit Conditions (ALL Must Be True)

1. ALL CRITICAL findings are resolved and verified by the raising reviewer
2. ALL HIGH findings are resolved OR explicitly deferred by the Super PM with justification
3. MEDIUM and LOW findings are tracked (deferred is acceptable with issue reference)
4. Every activated reviewer has set their findings file status to APPROVED
5. No reviewer has outstanding unverified findings

## Iteration Limits

There is no iteration cap. The loop runs until convergence. If convergence is not happening
(same issues recurring, fixes introducing new problems), Claude Marchetti reports the
situation to the Super PM with evidence. The Super PM decides whether to continue iterating,
re-scope the feature, or shelve it.

## Disagreements

If a builder disputes a reviewer's finding, the disagreement is escalated to the Super PM.
The builder and reviewer each present their case with evidence. The Super PM decides.

If two reviewers contradict each other (e.g., Marcus says the pattern is correct, James says
the scientific logic is wrong), both findings remain open until the contradiction is resolved.
Resolution may require an architecture decision session.
