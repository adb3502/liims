---
name: cross-domain-lessons
description: >
  Accumulated cross-domain lessons from past features. This file grows over time as
  retrospectives identify new patterns. Claude Marchetti reads this at the start of
  every feature session to load institutional memory. Entries are added during Phase 4
  retrospectives.
---

# Cross-Domain Lessons — Crucible Systems

This file is a living record of cross-domain patterns discovered during feature development.
Each entry represents a lesson that was learned through review, testing, or production
observation. Claude Marchetti reads this file at the start of every new feature to ensure
past lessons inform current work.

## How to Add Entries

After every Phase 4 retrospective, Claude Marchetti adds entries here for any cross-domain
pattern that was discovered. Each entry includes: the date, the feature that revealed it,
the pattern, and which review step should catch it in the future.

## Entries

(This file starts empty and accumulates entries over time. The first entry will be added
after the first feature completes the full BioAvengers workflow.)

<!-- Template for new entries:
### [DATE] — [Feature Name]
**Pattern**: [Description of the cross-domain issue]
**Discovered by**: [Which reviewer(s) or phase]
**Impact**: [What would have happened if not caught]
**Prevention**: [Which review step or skill file should catch this going forward]
-->
