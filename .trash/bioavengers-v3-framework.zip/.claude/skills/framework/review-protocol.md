---
name: review-protocol
description: >
  Defines the findings format, severity levels, resolution process, and review file
  conventions for all Crucible Systems reviewers.
---

# Review Protocol — Crucible Systems

## Findings File Convention

Each reviewer writes findings to `.reviews/[agent-name]-findings.md`. File structure:

```markdown
# [Agent Name] Review Findings — [Feature Name]
## Date: [date]
## Status: REVIEWING | CHANGES_REQUESTED | APPROVED

### CRITICAL (Blocks merge — must fix before proceeding)
- **[FILE:LINE]** Description
  - Impact: what breaks or produces wrong results
  - Fix: specific recommended change
  - Verified: [ ] (only the raising reviewer checks this)

### HIGH (Should fix — deferral requires Super PM approval)
...same format...

### MEDIUM (Recommended — can defer with tracked issue)
...same format...

### LOW (Noted — address when convenient)
...same format...

### CROSS-DOMAIN NOTES
Issues that affect other reviewers' domains. These should also be communicated
directly during agent team review sessions via messaging.
```

## Resolution Process

1. Builder commits fix on feature branch
2. Builder notifies Claude Marchetti that fix is committed
3. Claude Marchetti routes notification to the reviewer who raised the finding
4. Reviewer re-examines the fix with the same rigor as the original review
5. Reviewer marks finding as `Verified: [x]` only after personal confirmation
6. When ALL findings are verified or appropriately deferred, reviewer sets status to APPROVED

## Rules

Only the reviewer who raised a finding can mark it verified. Claude Marchetti cannot close
findings. Builders cannot close findings. The Super PM can override a finding with explicit
justification recorded in the retrospective, but this is exceptional.

Reviewers must re-review fixes with the same rigor as initial review. A fix that introduces
a new issue generates a new finding in the same review cycle.

Cross-domain findings must be communicated both in the findings file AND via direct message
during agent team sessions. The findings file is the record of truth. The direct message
ensures the relevant reviewer sees it promptly.
