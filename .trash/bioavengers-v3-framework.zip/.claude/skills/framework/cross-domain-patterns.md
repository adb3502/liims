---
name: cross-domain-patterns
description: >
  Known cross-domain failure modes in biological computing platforms. These patterns
  represent issues that live between specialist domains and are missed by single-domain
  review. Reference during review phases and when writing cross-domain findings.
---

# Cross-Domain Failure Patterns — Crucible Systems

## Security ↔ Science

**User input reaching computation engines.** Batch IDs, sample names, gene list inputs,
and filter parameters that are user-controlled but passed to R bridge expressions, SQL
queries, or file path construction. A user who enters `'); system('rm -rf /')` as a batch
name exploits both a security vulnerability and corrupts any analysis that uses batch as
a covariate.

**Manipulable normalization parameters.** User-selectable normalization methods where the
selection is passed directly to the computation engine without validation against an
allowlist. A user (or injected input) specifying a non-existent normalization method
could cause silent fallback to no normalization.

**Export endpoints leaking analysis parameters.** Analysis results exported as CSV or PDF
may include internal pipeline parameters (database IDs, file paths, intermediate computation
values) that reveal system internals or participant grouping information.

## Architecture ↔ UX

**API pagination breaking frontend workflows.** Backend pagination that returns
non-deterministic page contents when the underlying data changes between page requests,
causing gene lists to show duplicates or miss entries during user browsing.

**Error response formats without user context.** Backend returning structured error codes
that the frontend cannot map to user-actionable messages without a separate error catalog.
Results in raw "422 Unprocessable Entity" shown to wet-lab biologists.

**Async job completion without notification.** Long-running analysis jobs (DESeq2, GSEA,
aging clock computation) that complete without notifying the frontend, requiring users to
manually refresh or poll.

## Science ↔ UX

**Results without uncertainty.** Displaying fold change values, aging clock scores, or
enrichment statistics without confidence intervals, standard errors, or p-values. Users
treat displayed numbers as certain even when the underlying computation has wide uncertainty.

**Scale misrepresentation.** Linear axis on log-distributed data (gene expression counts),
truncated axes on bar charts (exaggerating small differences), heatmaps without row/column
normalization context.

**Suggestive labeling.** UI labels like "significant genes," "aging markers," or "risk
factors" that cross the Computation-Interpretation boundary. The platform computes. The
researcher interprets.

## Security ↔ Infrastructure

**Docker compose exposing internal ports.** Development configurations that bind internal
service ports (Redis, PostgreSQL, Celery Flower) to all interfaces rather than localhost,
persisting into production deployments.

**Default credentials in service configurations.** Redis without requirepass, PostgreSQL
with default passwords in docker-compose.yml, Celery broker URLs with credentials in
plain text.

**Log aggregation capturing sensitive data.** Centralized logging that captures request
bodies containing participant identifiers, genomic query parameters, or analysis
configurations that reveal study design.

## QA ↔ Science

**Mocked computation tests.** Tests that mock out the entire statistical computation and
only verify the API wrapper, proving nothing about scientific correctness. The test passes
even if the R bridge call has wrong parameters.

**Snapshot tests on scientific output.** Tests that compare current output to a saved
snapshot without verifying the snapshot itself is correct. If the initial snapshot was
wrong, the test perpetuates the error.

**Missing boundary condition tests for biological data.** No tests for zero-count genes,
samples with 100% mitochondrial reads, single-sample comparison groups, participants
outside aging clock training age range, metabolites below detection limit.
