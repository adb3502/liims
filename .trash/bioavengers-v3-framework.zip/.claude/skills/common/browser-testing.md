---
name: browser-testing
description: >
  Browser-based verification skill for visual UI testing, accessibility auditing,
  E2E workflow validation, and component state verification. Used by Robert (QA)
  and Alexandra (UX) during Phase 3c Integration and Phase 3d Polish. Supports
  Claude in Chrome (visual inspection), Playwright MCP (automated E2E), and
  Vercel agent-browser (snapshot-ref interaction). Load this skill whenever
  reviewing UI components, user workflows, or accessibility compliance.
---

# Browser Testing Skill — Crucible Systems

## Purpose

Code review catches structural problems. Browser testing catches experiential ones.
A component can have correct JSX, valid ARIA attributes, proper Tailwind classes, and
still be unusable — because the loading spinner is invisible against the background,
because the error message renders below the fold, because keyboard focus gets trapped
in a modal, because the data table is readable in code but incomprehensible at 1440px
with 200 rows of genomic data.

This skill equips Robert (QA) and Alexandra (UX) with browser-based verification
capabilities that complement their code-level review.

## Three Verification Methods

### Method 1: Claude in Chrome (Visual Inspection)

Requires: Claude Code launched with `--chrome` flag or `/chrome` enabled by default.
The Super PM must have the Claude in Chrome extension installed (v1.0.36+).

**When to use**: Manual visual verification of component states, color contrast in
context, layout at different viewport sizes, keyboard navigation flow, screen reader
compatibility assessment, visual regression checks against mockups.

**Workflow**:
```
1. Ensure the development server is running (npm run dev / docker compose up)
2. Claude navigates to the relevant page via Chrome
3. Take screenshots at each component state (loading, error, empty, populated)
4. Verify visual hierarchy, contrast ratios, focus indicators
5. Test keyboard navigation: Tab through all interactive elements
6. Test with simulated screen reader (check ARIA labels are meaningful)
7. Document findings with screenshots as evidence
```

**Key commands**:
```
Navigate to http://localhost:3000/analysis/deseq2
Take a screenshot of the current page state
Click the "Run Analysis" button
Fill the batch name field with "test_batch_001"
Check the browser console for errors
```

**Visual Checks (Alexandra)**:
- Color contrast: Does text meet 4.5:1 ratio against actual rendered background?
- Component states: Trigger each state and screenshot. Does loading have a meaningful
  indicator? Does error show a human-readable message with recovery action? Does empty
  guide the user? Does populated handle the actual data volume?
- Keyboard navigation: Tab order logical? Focus indicators visible? No keyboard traps?
- Responsive: Check at 1920px (lab workstation), 1440px (laptop), 1024px (tablet in
  field). Scientific data tables must be usable at each breakpoint.
- Color vision: Use Chrome DevTools → Rendering → Emulate vision deficiency to check
  deuteranopia, protanopia, tritanopia. No information conveyed by color alone.

**E2E Workflow Checks (Robert)**:
- Navigate the primary user workflow end-to-end as a real user would
- Verify all form validations fire with appropriate messages
- Confirm data persists after submission (refresh and verify)
- Test the error path: disconnect backend, verify graceful degradation
- Check console for JavaScript errors during the workflow
- Verify API calls match expected contracts (Network tab)

### Method 2: Playwright MCP (Automated E2E)

Requires: Playwright MCP server configured in `.claude/settings.json`.

**When to use**: Repeatable E2E test execution, regression testing, testing user
workflows that must pass on every build, verifying fix-verify cycles.

**Configuration** (add to `.claude/settings.json`):
```json
{
  "mcpServers": {
    "playwright": {
      "command": "npx",
      "args": ["-y", "@anthropic-ai/mcp-server-playwright", "--headless"]
    }
  }
}
```

**Workflow**:
```
1. Start the application (dev server or Docker Compose)
2. Use Playwright MCP to navigate to the target page
3. Execute the test scenario: fill forms, click buttons, verify responses
4. Take screenshots at verification points
5. Check for console errors
6. Verify network requests match API contracts
```

**Key patterns**:
```
Use Playwright to navigate to http://localhost:3000/specimens/new
Fill the participant ID field with "BHARAT-BLR-0042"
Click the "Add Specimen" button
Verify the success toast appears within 3 seconds
Take a screenshot for the review findings
Navigate to http://localhost:3000/specimens and verify the new specimen appears in the list
```

### Method 3: Vercel agent-browser (Snapshot-Ref Interaction)

Requires: `agent-browser` npm package installed.

**When to use**: Precise element targeting via accessibility-tree snapshots, testing
complex interactive components (data tables with sorting/filtering, multi-step wizards),
verifying ARIA structure matches visual presentation.

**Workflow**:
```bash
agent-browser open http://localhost:3000/analysis/deseq2
agent-browser snapshot -i    # Get interactive elements with refs (@e1, @e2...)
agent-browser click @e3      # Click specific element by ref
agent-browser fill @e5 "test_batch"  # Fill input by ref
agent-browser screenshot     # Capture visual state
```

**Why this matters for accessibility**: The snapshot command shows the accessibility
tree — what a screen reader sees. If an interactive element doesn't appear in the
snapshot, it's invisible to assistive technology regardless of how it looks visually.

## Integration with BioAvengers Phases

### Phase 3c: Integration — Robert's Browser Verification

After wiring frontend to real APIs, Robert runs the primary user workflow in an actual
browser. This catches issues that unit tests and API tests cannot:

- Frontend state management bugs that only appear with real async API calls
- Race conditions between loading states and data arrival
- Error handling when the backend returns unexpected shapes
- Session/authentication flow in context

**Robert's Integration Browser Checklist**:
```
[ ] Primary workflow completes end-to-end in browser
[ ] All API calls return expected status codes (Network tab)
[ ] No console errors during normal workflow
[ ] Error state triggered and recovery path works
[ ] Data persists after page refresh
[ ] Loading states appear and resolve within reasonable time
[ ] Browser back/forward navigation doesn't break state
```

### Phase 3d: Polish — Alexandra's Browser Verification

After the builders polish error handling, states, and accessibility, Alexandra
verifies IN THE BROWSER that the code-level accessibility work actually produces
an accessible experience:

**Alexandra's Polish Browser Checklist**:
```
[ ] All four component states verified visually (screenshot each)
[ ] Keyboard-only navigation: complete primary workflow without mouse
[ ] Focus indicators visible on every interactive element
[ ] Color contrast verified with DevTools at actual rendered sizes
[ ] Color vision deficiency simulation (all three types)
[ ] Error messages are human-readable with recovery action
[ ] Empty states provide helpful guidance
[ ] Loading indicators are meaningful (not just spinner)
[ ] Scientific results show units, uncertainty, and context
[ ] Data tables usable at 1920px and 1440px breakpoints
[ ] No text truncation hiding critical information
[ ] Tooltips/popovers don't overflow viewport
```

### Phase 4: Henrik's Optional Browser Check

Henrik's review is primarily code-based, but for features with significant UI
components, Henrik MAY use Claude in Chrome for a final visual sanity check. This
is not a full a11y audit (Alexandra already did that) — it's Henrik's "does this
actually work when I try to use it?" check. Finding a visual bug at Henrik's gate
that should have been caught earlier gets noted in the retrospective.

## Anti-Patterns

**DO NOT** use browser testing as a substitute for code-level review. Browser testing
catches experiential issues; code review catches structural ones. Both are required.

**DO NOT** rely solely on headless Playwright for accessibility testing. Headless
browsers don't render visual states the same way. Use Claude in Chrome for visual
verification.

**DO NOT** test only the happy path. Browser testing must include error states,
edge cases, and degraded conditions (backend down, slow network, large datasets).

**DO NOT** skip browser testing for "backend-only" changes that modify API response
shapes. If the response shape changed, the frontend experience may have changed.

## Evidence Requirements

Browser test findings MUST include:
- Screenshot of the issue (not just a description)
- Steps to reproduce (URL, actions taken)
- Expected vs actual behavior
- Which checklist item this addresses
- Severity rating consistent with the review findings format
